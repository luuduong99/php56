<?php 
	//load file Layout.php vao day
	$this->fileLayout = "Layout.php";
 ?>